<?php 
include_once('../data/admin_session.php');//check if naay session otherwise e return sa login
 ?>