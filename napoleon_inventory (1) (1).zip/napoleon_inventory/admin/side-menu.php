	<div id="left_content">
		<div class="panel-group">
 			 <div class="panel panel-primary">
 			 	<div class="panel-heading">Quick Access</div>
  	  			<div class="panel-body">
  	  				<ul class="">
  	  					<li>
                   <a id="addItem" href="#modal-add-item" data-toggle="modal">
                   <span class="glyphicon glyphicon-plus-sign"></span>
                   Add Item</a>    
                </li>

  	  					<li>
                  <a href="#modal-add-employee" id="add-employee-menu" data-toggle="modal">
                  <span class="glyphicon glyphicon-user"></span>
                  Add Employee</a> 
                </li>

                <li><a href="#modal-add-position" data-toggle="modal"><span class="glyphicon glyphicon-road"></span>
                  Add Position</a> 
                </li>

                 <li><a href="#modal-add-office" data-toggle="modal"><span class="glyphicon glyphicon-tower"></span>
                  Add Office</a> 
                </li>
  	  					
                <li>
                  <div>
                      <a href="item.php">
                  <span class="glyphicon glyphicon-refresh"></span>
                  Refresh</a>    
                    </div>  
                </li>

  	  				</ul>
  	  			</div>
 			 </div>
		</div>
	</div>

 
