<div class="container"> 
<nav class="navbar navbar-inverse" style="margin-top:5px;">
    <div class="container-fluid">
     <div class="banner">
                    <img src="../img/napoleon.png" width="300" height="120" style="position:absolute;margin-top:-20px;">
<div style="color:WHITE;margin-left:400px;margin-bottom:50px;margin-top:20px;font-size:70px;font-family:Bodoni MT Black;">INVENTORY </div>

               </div> 
     

     </div>
    </nav>